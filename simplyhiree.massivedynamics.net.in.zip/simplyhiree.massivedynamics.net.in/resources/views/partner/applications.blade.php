@extends('layouts.app')

@section('content')
<div class="container mx-auto py-8">
    <h1 class="text-4xl font-bold">Job Applications</h1>
    <div class="mt-8">
        <p>This page will show all the applications for your job posts.</p>
        
        {{-- We will add a table here later to list the applications --}}
        
    </div>
</div>
@endsection