@extends('layouts.app')

@section('content')
<div class="container mx-auto py-8">
    <h1 class="text-4xl font-bold">Your Earnings</h1>
    <div class="mt-8">
        <p>This page will show a summary of your earnings from successful placements.</p>
        
        {{-- Earnings details will be added here later --}}
        
    </div>
</div>
@endsection