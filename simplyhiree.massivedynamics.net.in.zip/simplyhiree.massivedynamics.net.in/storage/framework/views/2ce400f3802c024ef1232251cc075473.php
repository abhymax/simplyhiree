

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto py-8">
        <div class="bg-blue-900 text-white p-6 rounded-lg shadow-lg">
            <h1 class="text-4xl font-bold">Welcome, <?php echo e(Auth::user()->name); ?>!</h1>
            <p class="mt-2 text-xl">This is your candidate dashboard. You can apply for jobs and track your applications here.</p>
        </div>

        <!-- Example Section for Job Applications -->
        <div class="mt-8 bg-white p-6 rounded-lg shadow-lg">
            <h3 class="text-2xl font-bold">Your Applications</h3>
            <p class="mt-4 text-lg text-gray-600">See the status of your job applications here.</p>
            <a href="<?php echo e(route('candidate.applications')); ?>" class="text-blue-600 hover:underline">View Applications</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mas7415dyn/public_html/simplyhiree.massivedynamics.net.in/resources/views/candidate/dashboard.blade.php ENDPATH**/ ?>