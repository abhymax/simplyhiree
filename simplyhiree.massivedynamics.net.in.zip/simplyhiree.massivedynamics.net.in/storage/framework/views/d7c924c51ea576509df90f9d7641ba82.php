<h1>Available Jobs</h1>
<ul>
    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <h2><?php echo e($job->title); ?></h2>
            <p><?php echo e($job->description); ?></p>
            <a href="<?php echo e(route('jobs.show', $job->id)); ?>">View Details</a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="job-item">
        <h3><?php echo e($job->title); ?></h3>
        <p><?php echo e($job->description); ?></p>

        <!-- Apply Button -->
        <form action="/apply/<?php echo e($job->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Apply Now</button>
        </form>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH /home/mas7415dyn/public_html/simplyhiree.massivedynamics.net.in/resources/views/jobs/index.blade.php ENDPATH**/ ?>