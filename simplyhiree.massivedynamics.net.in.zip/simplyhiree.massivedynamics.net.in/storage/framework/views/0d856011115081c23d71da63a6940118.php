

<?php $__env->startSection('content'); ?>
<div class="py-12 bg-gray-100">
    <div class="container mx-auto px-4">

        <!-- *** THIS IS THE NEW SUCCESS MESSAGE BLOCK *** -->
        <?php if(session('success')): ?>
            <div class="mb-6 bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md shadow-md" role="alert">
                <p class="font-bold">Success</p>
                <p><?php echo e(session('success')); ?></p>
            </div>
        <?php endif; ?>
        <!-- *** END OF NEW SUCCESS MESSAGE BLOCK *** -->

        <!-- Dashboard Header -->
        <div class="flex flex-wrap justify-between items-center bg-gradient-to-r from-blue-700 to-indigo-800 text-white p-6 rounded-lg shadow-lg mb-8">
            <div>
                <h1 class="text-4xl font-bold">Welcome, <?php echo e(Auth::user()->name); ?>!</h1>
                <p class="mt-2 text-xl opacity-90">Partner Dashboard</p>
            </div>
            <a href="<?php echo e(route('partner.candidates.create')); ?>" class="mt-4 sm:mt-0 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-indigo-700 bg-white hover:bg-indigo-50 transform hover:scale-105 transition duration-300 ease-in-out">
                Add New Candidate
            </a>
        </div>

        <!-- Overview Section -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <!-- *** THIS IS THE NEW "CANDIDATE POOL" CARD *** -->
            <div class="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                <h3 class="text-2xl font-bold text-gray-800">My Candidate Pool</h3>
                <p class="mt-4 text-gray-600">View and manage all candidates you have added to the platform.</p>
                <a href="<?php echo e(route('partner.candidates.index')); ?>" class="mt-4 inline-block text-indigo-600 font-semibold hover:underline">View Candidates &rarr;</a>
            </div>
            <!-- *** END OF NEW CARD *** -->

            <div class="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                <h3 class="text-2xl font-bold text-gray-800">Available Vacancies</h3>
                <p class="mt-4 text-gray-600">View all approved job vacancies you can work on.</p>
                <a href="<?php echo e(route('partner.jobs')); ?>" class="mt-4 inline-block text-indigo-600 font-semibold hover:underline">View Jobs &rarr;</a>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                <h3 class="text-2xl font-bold text-gray-800">Your Applications</h3>
                <p class="mt-4 text-gray-600">Track the status of candidates you have submitted.</p>
                <a href="<?php echo e(route('partner.applications')); ?>" class="mt-4 inline-block text-indigo-600 font-semibold hover:underline">Manage Applications &rarr;</a>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                <h3 class="text-2xl font-bold text-gray-800">Earnings</h3>
                <p class="mt-4 text-gray-600">Track your earnings from successful placements.</p>
                <a href="<?php echo e(route('partner.earnings')); ?>" class="mt-4 inline-block text-indigo-600 font-semibold hover:underline">View Earnings &rarr;</a>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mas7415dyn/public_html/simplyhiree.massivedynamics.net.in/resources/views/partner/dashboard.blade.php ENDPATH**/ ?>