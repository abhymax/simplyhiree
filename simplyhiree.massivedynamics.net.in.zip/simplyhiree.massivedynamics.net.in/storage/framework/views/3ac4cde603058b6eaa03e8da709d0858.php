

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h1 class="text-4xl font-bold">Job Applications</h1>
    <div class="mt-8">
        <p>This page will show all the applications for your job posts.</p>
        
        
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mas7415dyn/public_html/simplyhiree.massivedynamics.net.in/resources/views/partner/applications.blade.php ENDPATH**/ ?>