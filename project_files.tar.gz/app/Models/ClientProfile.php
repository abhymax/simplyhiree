<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ClientProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'company_name',
        'official_email',
        'service_required',
        'website',
        'industry',
        'company_size',
        'description',
        'logo_path',
        'contact_person_name',
        'contact_phone',
        'gst_number',
        'address',
        'city',
        'state',
        'pincode',
        // Compliance Fields
        'pan_number',
        'pan_file_path',
        'tan_number',
        'tan_file_path',
        'coi_number',
        'coi_file_path',
        // NEW FIELD
        'other_docs', 
    ];

    // Automatically convert JSON to Array
    protected $casts = [
        'other_docs' => 'array',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}