<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use App\Models\Job;

class JobApproved extends Notification implements ShouldQueue
{
    use Queueable;

    public $job;

    public function __construct(Job $job)
    {
        $this->job = $job;
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toDatabase(object $notifiable): array
    {
        return [
            'message' => "Your job '{$this->job->title}' has been approved and is now live.",
            'job_id' => $this->job->id,
            'icon' => 'check-circle',
        ];
    }
}